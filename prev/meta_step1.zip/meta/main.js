document.addEventListener("DOMContentLoaded", async () => {
    await loadData();
});

let data = [];
let commits = [];

async function loadData() {
    data = await d3.csv("/meta/loc.csv", (row) => ({
        ...row,
        line: Number(row.line),
        depth: Number(row.depth),
        length: Number(row.length),
        date: new Date(row.date + "T00:00" + row.timezone),
        datetime: new Date(row.datetime),
    }));
    displayStats();
}

function processCommits() {
    commits = d3
        .groups(data, (d) => d.commit)
        .map(([commit, lines]) => {
            let first = lines[0];
            let { author, date, time, timezone, datetime } = first;
            let ret = {
                id: commit,
                url: "https://github.com/YOUR_REPO/commit/" + commit,
                author,
                date,
                time,
                timezone,
                datetime,
                hourFrac: datetime.getHours() + datetime.getMinutes() / 60,
                totalLines: lines.length,
            };

            Object.defineProperty(ret, "lines", {
                value: lines,
                configurable: false,
                writable: false,
                enumerable: false,
            });

            return ret;
        });
}

function displayStats() {
    processCommits();

    const statsData = [
        { label: "COMMITS", value: commits.length },
        { label: "FILES", value: d3.group(data, (d) => d.file).size },
        { label: "TOTAL LOC", value: data.length },
        { label: "MAX DEPTH", value: d3.max(data, (d) => d.depth) },
        { label: "LONGEST LINE", value: d3.max(data, (d) => d.length) },
        { label: "MAX LINES", value: d3.max(data, (d) => d.line) },
    ];

    const labelsContainer = d3.select("#stats-labels");
    labelsContainer.html("");
    labelsContainer
        .selectAll(".stat-label")
        .data(statsData)
        .enter()
        .append("div")
        .attr("class", "stat-label")
        .text((d) => d.label);

    const valuesContainer = d3.select("#stats-values");
    valuesContainer.html("");
    valuesContainer
        .selectAll(".stat-value")
        .data(statsData)
        .enter()
        .append("div")
        .attr("class", "stat-value")
        .text((d) => d.value);
}
